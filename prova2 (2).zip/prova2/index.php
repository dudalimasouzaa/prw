<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
</head>
<body>
    <h1>FLUXO DO CAIXA</h1>
    <hr>
    <div id="menu">
    <ul>
        <li><a href="cadastro_fluxo_caixa.htm">Cadastrar Fluxo de Caixa</a></li>
        <li><a href="listar_fluxo_caixa.php">Listagem de Fluxo de Caixa</a></li>
        <li><a href="consulta_fluxo_caixa.htm">Consulta Saldo do Caixa</a></li>
    </ul>
</div>
</body>
</html>